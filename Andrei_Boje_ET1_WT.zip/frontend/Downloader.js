class Downloader {

    downloadLatest() {
        alert('Download latest not implemented yet')
    }
}

export default Downloader